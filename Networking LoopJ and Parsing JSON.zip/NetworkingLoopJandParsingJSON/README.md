# QuoteApp_Android
This is a repository to learn networking with LoopJ, and parsing JSON in an android app that will take data from API and show text data on the app interface.
